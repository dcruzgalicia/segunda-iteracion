import { z } from 'zod';
import { ACCENT_COLORS } from '../lib/accent-palettes.js';
import {
  DEFAULT_EPUB_FORMAT,
  DEFAULT_HTML_FORMAT,
  DEFAULT_LATEX_FORMAT,
  DEFAULT_MARKDOWN_FORMAT,
  DEFAULT_PDF_FORMAT,
  DEFAULT_SITE_CONFIG,
} from './site-config.js';

z.setErrorMap(((issue: z.ZodIssue) => {
  if (issue.code === 'invalid_type') {
    const expected = (issue as { expected?: string }).expected ?? 'valor';
    const input = (issue as { input?: unknown }).input;
    const received = typeof input === 'string' ? input : JSON.stringify(input ?? 'desconocido');
    return { message: `se esperaba ${expected}, se recibió ${received}` };
  }
  if (issue.code === 'invalid_value') {
    const values = (issue as { values?: unknown[] }).values ?? [];
    const list = values.map((o) => JSON.stringify(o)).join(', ');
    return { message: list ? `valor no válido: se esperaba uno de ${list}` : 'valor no válido' };
  }
  if (issue.code === 'too_small') {
    return { message: `muy corto: mínimo ${issue.minimum}` };
  }
  if (issue.code === 'too_big') {
    return { message: `muy largo: máximo ${issue.maximum}` };
  }
  return { message: issue.message };
}) as unknown as z.ZodErrorMap);

const PAGE_NUMBER_OPTIONS = ['header-left', 'header-center', 'header-right', 'footer-left', 'footer-center', 'footer-right'] as const;

const DublinCoreFieldsSchema = {
  title: z.string().optional(),
  creator: z.union([z.string(), z.array(z.string())]).optional(),
  subject: z.union([z.string(), z.array(z.string())]).optional(),
  description: z.string().optional(),
  publisher: z.union([z.string(), z.array(z.string())]).optional(),
  contributor: z.union([z.string(), z.array(z.string())]).optional(),
  date: z.string().optional(),
  identifier: z.string().optional(),
  source: z.string().optional(),
  relation: z.union([z.string(), z.array(z.string())]).optional(),
  coverage: z.string().optional(),
  rights: z.string().optional(),
  license: z.union([z.string(), z.literal(false)]).optional(),
  doi: z.string().optional(),
  isbn: z.string().optional(),
  abstract: z.string().optional(),
};

const TitlePageFieldsSchema = {
  subtitle: z.string().optional(),
  extratitle: z.string().optional(),
  frontispiece: z.string().optional(),
  titlehead: z.string().optional(),
  collectionCreatorPrefix: z.string().optional(),
  dedication: z.string().optional(),
  uppertitleback: z.string().optional(),
  lowertitleback: z.string().optional(),
  colophon: z.string().optional(),
};

const ImageFieldsSchema = {
  titleImage: z.string().optional(),
  publisherImage: z.union([z.string(), z.array(z.string())]).optional(),
  startpaper: z.string().optional(),
  frontCover: z.string().optional(),
  backCover: z.string().optional(),
};

const HtmlSiteSchema = z
  .object({
    title: z.string().default(DEFAULT_HTML_FORMAT.site.title),
    description: z.string().default(DEFAULT_HTML_FORMAT.site.description),
    logo: z.string().default(DEFAULT_HTML_FORMAT.site.logo),
    logoSize: z.string().optional().default(DEFAULT_HTML_FORMAT.site.logoSize),
    theme: z.enum(['light', 'dark']).optional().default(DEFAULT_HTML_FORMAT.site.theme),
    color: z.enum(ACCENT_COLORS).optional().default(DEFAULT_HTML_FORMAT.site.color),
    links: z.array(z.object({ name: z.string(), url: z.string() }).strict()).optional(),
    license: z.union([z.string(), z.literal(false)]).optional(),
  })
  .strict();

const HtmlFormatSchema = z
  .object({
    site: HtmlSiteSchema.optional(),
    generate: z.boolean().default(DEFAULT_HTML_FORMAT.generate),
    pageSize: z.number().int().min(1).optional().default(DEFAULT_HTML_FORMAT.pageSize),
  })
  .strict();

const PdfFormatSchema = z
  .object({
    generate: z.boolean().default(DEFAULT_PDF_FORMAT.generate),
    showDate: z.boolean().optional(),
    pageNumber: z.enum(PAGE_NUMBER_OPTIONS).optional(),
    disabledPreambleFilters: z.array(z.string()).optional(),
    coverImage: z.boolean().optional(),
    courtesyPage: z.boolean().optional(),
    coverColor: z.boolean().optional(),
    ...ImageFieldsSchema,
    ...DublinCoreFieldsSchema,
    ...TitlePageFieldsSchema,
  })
  .strict();

const LatexFormatSchema = z
  .object({
    generate: z.boolean().default(DEFAULT_LATEX_FORMAT.generate),
  })
  .strict();

const EpubFormatSchema = z
  .object({
    generate: z.boolean().default(DEFAULT_EPUB_FORMAT.generate),
  })
  .strict();

const MarkdownFormatSchema = z
  .object({
    generate: z.boolean().default(DEFAULT_MARKDOWN_FORMAT.generate),
    merge: z.boolean().default(DEFAULT_MARKDOWN_FORMAT.merge),
  })
  .strict();

const FormatSchema = z
  .object({
    latex: LatexFormatSchema.optional(),
    html: HtmlFormatSchema.optional(),
    pdf: PdfFormatSchema.optional(),
    epub: EpubFormatSchema.optional(),
    markdown: MarkdownFormatSchema.optional(),
  })
  .strict();

export const SiteConfigSchema = z
  .object({
    language: z.string().default(DEFAULT_SITE_CONFIG.language),
    toc: z.boolean().default(DEFAULT_SITE_CONFIG.toc),

    script: z.boolean().default(DEFAULT_SITE_CONFIG.script),

    bundle: z.boolean().default(DEFAULT_SITE_CONFIG.bundle),
    format: FormatSchema.optional(),
    bibliography: z.string().optional(),
    csl: z.string().optional(),
    showDate: z.boolean().optional(),
    pageNumber: z.enum(PAGE_NUMBER_OPTIONS).optional(),
    coverImage: z.boolean().optional(),
    courtesyPage: z.boolean().optional(),
    coverColor: z.boolean().optional(),
    disabledPreambleFilters: z.array(z.string()).optional(),
    disabledFilters: z
      .array(z.string())
      .transform((v) => (v?.length ? v : undefined))
      .optional(),
    luaFilters: z
      .array(z.string())
      .transform((v) => (v?.length ? v : undefined))
      .optional(),
    ...ImageFieldsSchema,
    ...DublinCoreFieldsSchema,
    ...TitlePageFieldsSchema,
  })
  .strict()
  .transform((raw) => ({
    ...raw,
    format: {
      latex: raw.format?.latex ?? { ...DEFAULT_LATEX_FORMAT },
      html: raw.format?.html ?? { ...DEFAULT_HTML_FORMAT },
      pdf: raw.format?.pdf ?? ({ generate: DEFAULT_PDF_FORMAT.generate } as z.infer<typeof PdfFormatSchema>),
      epub: raw.format?.epub ?? { ...DEFAULT_EPUB_FORMAT },
      markdown: raw.format?.markdown ?? { ...DEFAULT_MARKDOWN_FORMAT },
    },
  }));

export type SiteConfig = z.infer<typeof SiteConfigSchema>;
