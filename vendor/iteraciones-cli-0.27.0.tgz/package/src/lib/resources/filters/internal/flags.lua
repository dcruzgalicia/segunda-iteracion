local SECTION_COMMANDS = {
  subsubsection = true,
  subsection = true,
  section = true,
  subparagraph = true,
  paragraph = true,
  chapter = true,
  part = true,
}

local function is_header(b)
  return b.t == 'Header'
end

local function is_section_raw(b)
  if b.t ~= 'RawBlock' then return false end
  local fmt, text
  if b.c ~= nil then
    fmt, text = b.c[1], b.c[2]
  else
    fmt, text = b.format, b.text
  end
  if (fmt ~= 'tex' and fmt ~= 'latex') or type(text) ~= 'string' then return false end
  local cmd = text:match('^\\([%a]+)')
  if cmd == nil or not SECTION_COMMANDS[cmd] then return false end
  local rest = text:sub(#cmd + 2)
  if rest:sub(1, 1) == '*' then rest = rest:sub(2) end
  if #rest == 0 then return true end
  local c = rest:sub(1, 1)
  return c == '[' or c == '{' or c == ' ' or c == '\t'
end

local function is_list_opener(b)
  if b.t == 'BlockQuote' then return true end
  if b.t == 'Div' then
    for _, cls in ipairs(b.classes or {}) do
      if cls == 'dictum' or cls == 'verse' or cls == 'quote' or cls == 'japanese' or cls == 'chinese' or cls == 'korean' then return true end
    end
  end
  return false
end

local function split_first_section_command(text)
  local cmd = text:match('^\\([%a]+)')
  if cmd == nil then return text, nil end
  local i = #cmd + 2
  if text:sub(i, i) == '*' then i = i + 1 end
  while text:sub(i, i) == ' ' or text:sub(i, i) == '\t' do i = i + 1 end
  local open = text:find('{', i)
  if open == nil then return text, nil end
  local depth = 0
  for j = open, #text do
    local c = text:sub(j, j)
    if c == '{' then
      depth = depth + 1
    elseif c == '}' then
      depth = depth - 1
      if depth == 0 then
        local rest = text:sub(j + 1)
        if rest:find('\\[%a]') then
          return text:sub(1, j), rest
        end
        return text, nil
      end
    end
  end
  return text, nil
end

function Pandoc(doc)
  local has_cites = false
  local has_toc_entries = false
  local detect = {
    Cite = function(c)
      has_cites = true
      return c
    end,
    Header = function(h)
      has_toc_entries = true
      return h
    end,
    RawBlock = function(b)
      if is_section_raw(b) then has_toc_entries = true end
      return b
    end,
  }
  local nb = {}
  for _, b in ipairs(doc.blocks) do
    if is_header(b) or is_section_raw(b) then has_toc_entries = true end
    table.insert(nb, pandoc.walk_block(b, detect))
  end
  doc.blocks = nb

  if FORMAT == 'latex' then
    local is_intervention = doc.meta.intervention ~= nil
    local first = doc.blocks[1]
    local section_start = first ~= nil and (is_header(first) or is_section_raw(first))
    local list_start = first ~= nil and is_list_opener(first)
    local skip = section_start or list_start

    if not skip and first ~= nil and first.t == 'Para' then
      table.insert(first.content, 1, pandoc.RawInline('latex', '\\noindent '))
    end

    if not is_intervention then
      local page_cmd = doc.meta['page-number-command']
      local page_cmd_text
      if type(page_cmd) == 'string' then
        page_cmd_text = page_cmd
      elseif type(page_cmd) == 'table' and page_cmd.text ~= nil then
        page_cmd_text = page_cmd.text
      end
      if page_cmd_text ~= nil and page_cmd_text ~= '' then
        doc.meta['page-number-command'] = pandoc.MetaInlines({ pandoc.RawInline('latex', page_cmd_text) })
      end
      if skip and page_cmd_text ~= nil and page_cmd_text ~= '' then
        local is_footer = page_cmd_text:find('foot', 1, true) ~= nil
        local page_style = is_footer and '\\thispagestyle{plain}' or '\\thispagestyle{empty}'
        local function insert_page_cmd(pos)
          table.insert(doc.blocks, pos, pandoc.RawBlock('latex', page_style))
          table.insert(doc.blocks, pos + 1, pandoc.RawBlock('latex', page_cmd_text))
        end
        if first.t == 'RawBlock' then
          local head, rest = split_first_section_command(first.text)
          if rest ~= nil then
            first.text = head
            insert_page_cmd(2)
            table.insert(doc.blocks, 4, pandoc.RawBlock('latex', rest))
          else
            insert_page_cmd(2)
          end
        else
          insert_page_cmd(2)
        end
      end
    end

    doc.meta['has-toc-entries'] = pandoc.MetaBool(has_toc_entries)
    doc.meta['skip-paragraph-space'] = pandoc.MetaBool(skip)

    if has_cites and doc.meta.bibliography ~= nil and doc.meta['biblatex-available'] ~= false then
      table.insert(doc.blocks, pandoc.RawBlock('latex', '\\printbibliography[heading=bibintoc]'))
    end
  elseif FORMAT == 'html5' then
    if has_cites and doc.meta.bibliography ~= nil then
      table.insert(doc.blocks, pandoc.Header(1, pandoc.Str('Referencias'), pandoc.Attr('refs-heading', {}, {})))
      doc.meta['has-references'] = pandoc.MetaBool(true)
    end
  end
  return doc
end
