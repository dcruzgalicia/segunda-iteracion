local BS = '\1'

local function escape_latex(s)
  s = s:gsub('\\', BS)
  s = s:gsub('{', '\\{')
  s = s:gsub('}', '\\}')
  s = s:gsub('%$', '\\$')
  s = s:gsub('&', '\\&')
  s = s:gsub('#', '\\#')
  s = s:gsub('%^', '\\textasciicircum{}')
  s = s:gsub('_', '\\_')
  s = s:gsub('~', '\\textasciitilde{}')
  s = s:gsub('%%', '\\%')
  s = s:gsub(BS, '\\textbackslash{}')
  return s
end

local function inlines_to_latex(inlines)
  local out = {}
  for _, inl in ipairs(inlines) do
    if inl.t == 'Str' then
      table.insert(out, escape_latex(inl.text))
    elseif inl.t == 'Space' or inl.t == 'SoftBreak' then
      table.insert(out, ' ')
    elseif inl.t == 'LineBreak' then
      table.insert(out, '\\\\')
    elseif inl.t == 'Emph' then
      table.insert(out, '\\emph{' .. inlines_to_latex(inl.content) .. '}')
    elseif inl.t == 'Strong' then
      table.insert(out, '\\textbf{' .. inlines_to_latex(inl.content) .. '}')
    elseif inl.t == 'Code' then
      table.insert(out, escape_latex(inl.text))
    elseif inl.t == 'Link' or inl.t == 'Quoted' or inl.t == 'Cite' then
      table.insert(out, inlines_to_latex(inl.content))
    elseif inl.t == 'RawInline' and inl.format == 'latex' then
      table.insert(out, inl.text)
    end
  end
  return table.concat(out)
end

local function has_class(block, cls)
  if block.t ~= 'Div' then return false end
  for _, c in ipairs(block.classes) do
    if c == cls then return true end
  end
  return false
end

local DEFAULT_WIDTH = 0.5
local MIN_WIDTH = 0.1
local MAX_WIDTH = 1.0

local function resolve_dictum_width(div)
  local raw = div.attributes['width']
  if not raw then return nil end
  local num = tonumber(raw)
  if not num or num < MIN_WIDTH or num > MAX_WIDTH then return nil end
  return num
end

local function process_dictum(div, width)
  local quote_blocks = {}
  local author_latex = ''
  for _, block in ipairs(div.content) do
    if has_class(block, 'author') then
      local all_paras = true
      local inlines = {}
      local para_count = 0
      for _, b in ipairs(block.content) do
        if b.t == 'Para' then
          if para_count > 0 and #inlines > 0 then
            table.insert(inlines, pandoc.Space())
          end
          para_count = para_count + 1
          for _, inl in ipairs(b.content) do table.insert(inlines, inl) end
        else
          all_paras = false
        end
      end
      if all_paras and #inlines > 0 then
        author_latex = inlines_to_latex(inlines)
      else
        table.insert(quote_blocks, block)
      end
    else
      table.insert(quote_blocks, block)
    end
  end

  local solo_parrafos = true
  for _, block in ipairs(quote_blocks) do
    if block.t ~= 'Para' then
      solo_parrafos = false
      break
    end
  end
  if #quote_blocks > 0 and not solo_parrafos then
    local inicio = pandoc.RawBlock('latex', '\\begin{dictumbloque}[' .. author_latex .. ']{' .. width .. '}')
    local fin = pandoc.RawBlock('latex', '\\end{dictumbloque}')
    local result = { inicio }
    for _, block in ipairs(quote_blocks) do table.insert(result, block) end
    table.insert(result, fin)
    return result
  end

  local opening = '\\dictum'
  if author_latex ~= '' then
    opening = opening .. '[' .. author_latex .. ']'
  end
  opening = opening .. '{'
  local width_arg = '{' .. width .. '}'
  local closing = '}'

  if #quote_blocks == 0 then
    return {
      pandoc.RawBlock('latex', opening),
      pandoc.RawBlock('latex', closing),
      pandoc.RawBlock('latex', width_arg),
    }
  end

  local result = {}
  for i, block in ipairs(quote_blocks) do
    local is_first = i == 1
    local is_last = i == #quote_blocks
    if block.t == 'Para' then
      if is_first then table.insert(block.content, 1, pandoc.RawInline('latex', opening)) end
      if is_last then
        table.insert(block.content, pandoc.RawInline('latex', closing))
        table.insert(block.content, pandoc.RawInline('latex', width_arg))
      end
      table.insert(result, block)
    else
      if is_first then
        table.insert(result, pandoc.RawBlock('latex', opening))
      end
      table.insert(result, block)
      if is_last then
        table.insert(result, pandoc.RawBlock('latex', closing))
        table.insert(result, pandoc.RawBlock('latex', width_arg))
      end
    end
  end
  return result
end

function Pandoc(doc)
  local result = {}
  local last_was_dictum = false
  for _, block in ipairs(doc.blocks) do
    if has_class(block, 'dictum') then
      local width = resolve_dictum_width(block) or DEFAULT_WIDTH
      local expanded = process_dictum(block, width)
      for _, b in ipairs(expanded) do table.insert(result, b) end
      last_was_dictum = true
    elseif last_was_dictum and block.t == 'Para' then
      table.insert(block.content, 1, pandoc.RawInline('latex', '\\noindent '))
      table.insert(result, block)
      last_was_dictum = false
    elseif last_was_dictum and block.t == 'RawBlock' then
      table.insert(result, block)
    else
      table.insert(result, block)
      last_was_dictum = false
    end
  end
  doc.blocks = result
  return doc
end
