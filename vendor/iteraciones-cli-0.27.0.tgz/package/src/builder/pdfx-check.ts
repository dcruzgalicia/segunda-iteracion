import { existsSync, statSync } from 'node:fs';
import { chmod, copyFile, mkdir } from 'node:fs/promises';
import { homedir } from 'node:os';
import { dirname, join } from 'node:path';
import type { SiteConfig } from '../config/config-schema.js';
import { resolveDisabledPreambleConfig } from '../config/site-config.js';
import { BuildError } from '../lib/errors.js';
import { GLYPHS, logInfo, logWarning } from '../lib/logger.js';
import { posix } from '../lib/paths.js';
import { plural } from '../lib/plural.js';
import { cpuConcurrency, exec, mapWithConcurrency } from '../lib/run.js';
import { recordSupportCommand } from '../lib/script-recorder.js';
import { hashFileContent } from './state-serialize.js';

const PDFCHECK_BIN_NAME = 'iteraciones-pdfcheck';

const CARGO_BUILD_TIMEOUT_MS = 600_000;

const PDFCHECK_TIMEOUT_MS = 30_000;

function managedBinDir(): string {
  const xdg = process.env.XDG_CACHE_HOME?.trim();
  const base = xdg && xdg.length > 0 ? xdg : join(homedir(), '.cache');
  return join(base, 'iteraciones', 'bin');
}

export async function resolvePdfCheckBinary(): Promise<string | null> {
  const managed = join(managedBinDir(), PDFCHECK_BIN_NAME);
  if (existsSync(managed)) return managed;
  return (await Bun.which(PDFCHECK_BIN_NAME)) ?? null;
}

async function buildPdfCheckBinary(): Promise<string | null> {
  const manifest = join(import.meta.dir, '../../tools/pdfx-validator/Cargo.toml');
  if (!existsSync(manifest)) return null;
  logInfo('compilando iteraciones-pdfcheck (primer build, puede tardar varios minutos)…', 'pdfx', process.stderr);
  try {
    await exec('cargo', ['build', '--release', '--quiet', '--manifest-path', manifest], {
      timeoutMs: CARGO_BUILD_TIMEOUT_MS,
    });
  } catch {
    return null;
  }
  const built = join(dirname(manifest), 'target', 'release', PDFCHECK_BIN_NAME);
  if (!existsSync(built)) return null;
  const destDir = managedBinDir();
  await mkdir(destDir, { recursive: true });
  const dest = join(destDir, PDFCHECK_BIN_NAME);
  await copyFile(built, dest);
  await chmod(dest, 0o755);
  return dest;
}

interface PdfCheckIssue {
  code: string;
  message: string;
  page: number | null;
  objectId: number | null;
  clause: string | null;
}

interface PdfCheckResult {
  valid: boolean;
  level: string;
  errors: PdfCheckIssue[];
  warnings: PdfCheckIssue[];
}

function failure(code: string, message: string): PdfCheckResult {
  return {
    valid: false,
    level: 'PDF/X-1a',
    errors: [{ code, message, page: null, objectId: null, clause: null }],
    warnings: [],
  };
}

export async function validatePdfX1a(pdfPath: string, binaryPath: string): Promise<PdfCheckResult> {
  let result: Awaited<ReturnType<typeof exec>>;
  try {
    result = await exec(binaryPath, [pdfPath], { timeoutMs: PDFCHECK_TIMEOUT_MS });
  } catch (err) {
    return failure('PDFCHECK_RUN', err instanceof Error ? err.message : String(err));
  }

  if (result.exitCode === 0) recordSupportCommand('validate', pdfPath, [binaryPath, pdfPath]);
  try {
    return JSON.parse(result.stdout) as PdfCheckResult;
  } catch {
    return failure('PDFCHECK_OUTPUT', `salida inesperada del binario: ${result.stderr.trim() || result.stdout.trim()}`);
  }
}

type PdfxOutputValidationResult = {
  validated: number;
  failed: number;
  summaryLine: string | undefined;
};

export interface PdfxCacheHandle {
  prev: Record<string, string>;
  out: Record<string, string>;
}

async function resolveBinary(options: { allowBuild?: boolean }): Promise<string | null> {
  let binary = await resolvePdfCheckBinary();
  if (!binary && options.allowBuild) binary = await buildPdfCheckBinary();
  if (!binary) {
    logWarning(
      'el binario de validación PDF/X-1a no está disponible y no se pudo compilar (instala Rust con rustup: https://doc.rust-lang.org/book/ch01-01-installation.html, o descarga el precompilado): los PDF no se validaron',
      'pdfx',
    );
  }
  return binary;
}

function getBinFingerprint(binary: string): string {
  try {
    const st = statSync(binary);
    return `${Math.round(st.mtimeMs)}:${st.size}`;
  } catch {
    return 'desconocido';
  }
}

async function buildCacheKeys(
  pdfs: string[],
  outputDir: string,
  binFp: string,
  disabled: string[],
  cache: PdfxCacheHandle,
): Promise<{ pendientes: string[]; claves: string[]; preValidated: number }> {
  const cacheKeyFor = async (file: string): Promise<string> =>
    `${file}\0${await hashFileContent(join(outputDir, file)).catch(() => 'ilegible')}\0${binFp}\0${disabled.join(',')}`;

  const claves = await Promise.all(pdfs.map(cacheKeyFor));
  const pendientes: string[] = [];
  let preValidated = 0;
  for (const [i, key] of claves.entries()) {
    if (cache.prev[key] === '1') preValidated++;
    else pendientes.push(pdfs[i] as string);
  }
  return { pendientes, claves, preValidated };
}

function processResult(
  file: string,
  result: PdfCheckResult | undefined,
  claves: string[],
  i: number,
  cache: PdfxCacheHandle,
): { failed: boolean; falloLines: string[] } {
  const where = (iss: PdfCheckIssue): string => (iss.page !== null && iss.page !== undefined ? ` — página ${iss.page + 1}` : '');
  if (result === undefined) {
    return { failed: false, falloLines: [`${file}: sin resultado del validador`] };
  }
  if (!result.valid) {
    const lines = [`${file}: no cumple PDF/X-1a (${plural(result.errors.length, 'fallo', 'fallos')})`];
    for (const e of result.errors) lines.push(`  [${e.code}] ${e.message}${where(e)}`);
    for (const w of result.warnings) lines.push(`  advertencia — [${w.code}] ${w.message}${where(w)}`);
    return { failed: true, falloLines: lines };
  }
  const key = claves[i];
  if (result.warnings.length === 0 && key !== undefined) cache.out[key] = '1';
  for (const w of result.warnings) {
    logWarning(`${file}: advertencia PDF/X-1a — [${w.code}] ${w.message}${where(w)}`, 'pdfx');
  }
  return { failed: false, falloLines: [] };
}

function finalizeCache(cache: PdfxCacheHandle, claves: string[]): void {
  const vigentes = new Set(claves);
  for (const key of Object.keys(cache.prev)) {
    const prev = cache.prev[key];
    if (prev !== undefined && vigentes.has(key) && cache.out[key] === undefined) cache.out[key] = prev;
  }
}

function isCached(claves: string[], i: number, cache: PdfxCacheHandle): boolean {
  const key = claves[i];
  return key !== undefined && cache.prev[key] === '1';
}

function mapResultsToFiles(
  pendientes: string[],
  results: Awaited<ReturnType<typeof validatePdfX1a>>[],
): Map<string, Awaited<ReturnType<typeof validatePdfX1a>>> {
  const porFile = new Map<string, Awaited<ReturnType<typeof validatePdfX1a>>>();
  for (const [i, result] of results.entries()) {
    const file = pendientes[i];
    if (file !== undefined && result !== undefined) porFile.set(file, result);
  }
  return porFile;
}

function existingInScope(outputDir: string, scope: string[]): string[] {
  const files = new Set<string>();
  for (const raw of scope) {
    const rel = posix(raw);
    if (rel === '' || rel.startsWith('/') || rel.split('/').includes('..')) continue;
    if (existsSync(join(outputDir, rel))) files.add(rel);
  }
  return [...files].sort();
}

function listPdfsToValidate(outputDir: string, scope?: string[]): string[] {
  if (scope !== undefined) return existingInScope(outputDir, scope);
  return [...new Bun.Glob('**/*.pdf').scanSync({ cwd: outputDir, onlyFiles: true })].sort();
}

export async function runPdfxOutputValidation(
  outputDir: string,
  siteConfig: SiteConfig,
  options: { allowBuild?: boolean } = {},
  effectiveDisabledPreamble?: string[],
  cache: PdfxCacheHandle = { prev: {}, out: {} },

  scope?: string[],
): Promise<PdfxOutputValidationResult> {
  const disabled = effectiveDisabledPreamble ?? resolveDisabledPreambleConfig(siteConfig);
  if (disabled.includes('99-pdfx')) return { validated: 0, failed: 0, summaryLine: undefined };
  if (!existsSync(outputDir)) return { validated: 0, failed: 0, summaryLine: undefined };
  const pdfs = listPdfsToValidate(outputDir, scope);
  if (pdfs.length === 0) return { validated: 0, failed: 0, summaryLine: undefined };

  const binary = await resolveBinary(options);
  if (!binary) return { validated: 0, failed: 0, summaryLine: undefined };

  const binFp = getBinFingerprint(binary);
  const { pendientes, claves, preValidated } = await buildCacheKeys(pdfs, outputDir, binFp, disabled, cache);
  const results = await mapWithConcurrency(pendientes, cpuConcurrency(4), (file) => validatePdfX1a(join(outputDir, file), binary));
  const porFile = mapResultsToFiles(pendientes, results);

  let validated = preValidated;
  let failed = 0;
  const fallos: string[] = [];
  for (const [i, file] of pdfs.entries()) {
    if (isCached(claves, i, cache)) continue;
    const result = porFile.get(file);
    const { failed: wasFailed, falloLines } = processResult(file, result, claves, i, cache);
    validated++;
    if (wasFailed) failed++;
    fallos.push(...falloLines);
  }
  finalizeCache(cache, claves);
  if (failed > 0) {
    throw new BuildError(`${failed} de ${validated} PDFs no certifican PDF/X-1a.\n${fallos.map((l) => `  ${l}`).join('\n')}`);
  }
  return {
    validated,
    failed,
    summaryLine: `${GLYPHS.success} Validación PDF/X-1a: ${validated} ${validated === 1 ? 'PDF certifica' : 'PDFs certifican'} PDF/X-1a`,
  };
}
