import { readFile } from 'node:fs/promises';
import { join, relative } from 'node:path';
import { resolveCollectionFile } from '../builder/collection-files.js';
import { listMarkdownDocuments } from '../builder/discover-files.js';
import { projectFilterNames, validateDisabledFilters } from '../builder/filter-resolver.js';
import { resolveEffectiveDisabledPreamble, validateDisabledPreambleFilters, validatePreambleDependencies } from '../builder/preamble-loader.js';
import {
  dictumWidthWarnings,
  dictumWidthWarningsInYaml,
  dictumWidthWarningsMessage,
  MISSING_TITLE_WARNING,
  validateConfigFilePaths,
  validateConfigRules,
  validateFrontmatterFields,
} from '../builder/project-validator.js';
import { outputKeyFor } from '../builder/slug-resolver.js';
import { loadSiteConfig } from '../config/config-loader.js';
import { resolveDisabledPreambleConfig } from '../config/site-config.js';
import { ConfigError, translateSystemError } from '../lib/errors.js';
import { applyCreatorTitle, parseYamlWithPosition, splitFrontmatter } from '../lib/frontmatter.js';
import { logError, logInfo, logWarning, writeJson } from '../lib/logger.js';
import { plural } from '../lib/plural.js';

type ValidationError = { file: string; message: string };

type ValidationResult = {
  errors: ValidationError[];
  warnings: ValidationError[];
  count: number;
};

function handleNoFrontmatter(entry: string, body: string, raw: string, errors: ValidationError[], warnings: ValidationError[]): void {
  if (!body.trim()) {
    errors.push({
      file: entry,
      message: raw.startsWith('---')
        ? 'no tiene contenido después del frontmatter; agrega un body para proceder con el build'
        : 'documento vacío; agrega un body para proceder con el build',
    });
  } else if (/^---\r?\n/.test(raw)) {
    warnings.push({
      file: entry,
      message: 'frontmatter sin cerrar (falta el bloque "---" final); el contenido se tratará como cuerpo',
    });
  } else {
    warnings.push({ file: entry, message: MISSING_TITLE_WARNING.message });
  }
}

function validateParsedFrontmatter(
  entry: string,
  parsed: Record<string, unknown>,
  slugs: Map<string, string>,
  errors: ValidationError[],
  warnings: ValidationError[],
): boolean {
  let fmError = false;
  for (const issue of validateFrontmatterFields(parsed)) {
    if (issue.severity === 'error') {
      fmError = true;
      errors.push({ file: entry, message: issue.message });
    } else {
      warnings.push({ file: entry, message: issue.message });
    }
  }
  const slug = typeof parsed.slug === 'string' ? parsed.slug.trim() : undefined;
  if (slug) {
    const outputKey = outputKeyFor(entry, slug);
    const owner = slugs.get(outputKey);
    if (owner !== undefined) {
      fmError = true;
      errors.push({ file: entry, message: `slug duplicado: "${slug}" ya lo usa ${owner}` });
    } else {
      slugs.set(outputKey, entry);
    }
  }
  applyCreatorTitle(parsed);
  if (parsed.title === undefined || parsed.title === '') {
    warnings.push({ file: entry, message: MISSING_TITLE_WARNING.message });
  }
  return fmError;
}

async function validateCollectionFiles(cwd: string, entry: string, parsed: Record<string, unknown>, errors: ValidationError[]): Promise<boolean> {
  if (parsed.type !== 'collection' || !Array.isArray(parsed.files)) return false;
  let failed = false;
  for (const file of parsed.files) {
    if (typeof file !== 'string') continue;
    const resolution = await resolveCollectionFile(file, entry, cwd);
    if (!resolution.ok) {
      failed = true;
      errors.push({ file: entry, message: `files: no encontrado "${file}" (probado: ${resolution.tried.join(', ')})` });
    }
  }
  return failed;
}

async function validateParsedYaml(
  cwd: string,
  entry: string,
  yaml: string,
  body: string,
  slugs: Map<string, string>,
  errors: ValidationError[],
  warnings: ValidationError[],
): Promise<boolean> {
  const yamlResult = parseYamlWithPosition(yaml);
  if (yamlResult.error) {
    errors.push({ file: entry, message: `frontmatter YAML inválido: ${yamlResult.error}` });
    return true;
  }
  const result = yamlResult.value;
  if (!result || typeof result !== 'object' || Array.isArray(result)) {
    errors.push({ file: entry, message: 'frontmatter YAML inválido: debe ser un objeto' });
    return true;
  }
  let fmError = validateParsedFrontmatter(entry, result as Record<string, unknown>, slugs, errors, warnings);
  if (await validateCollectionFiles(cwd, entry, result as Record<string, unknown>, errors)) fmError = true;

  const type = (result as Record<string, unknown>).type;
  if (!body.trim() && !fmError && type !== 'collection' && type !== 'intervention' && type !== 'menu') {
    errors.push({ file: entry, message: 'no tiene contenido después del frontmatter; agrega un body para proceder con el build' });
    fmError = true;
  }
  return fmError;
}

async function validateSingleEntry(
  cwd: string,
  entry: string,
  slugs: Map<string, string>,
  errors: ValidationError[],
  warnings: ValidationError[],
): Promise<boolean> {
  const absPath = join(cwd, entry);
  let raw: string;
  try {
    raw = await readFile(absPath, 'utf8');
  } catch (err) {
    errors.push({ file: entry, message: `no se pudo leer: ${translateSystemError(err, 'verifica que el nombre del archivo sea correcto')}` });
    return false;
  }
  const { yaml, body } = splitFrontmatter(raw);
  const lineOffset = raw.slice(0, raw.length - body.length).split('\n').length - 1;
  const dictumWidths = dictumWidthWarnings(body, lineOffset);
  if (dictumWidths.length > 0) {
    warnings.push({ file: entry, message: dictumWidthWarningsMessage(dictumWidths) });
  }
  if (yaml) {
    const yamlDictumWidths = dictumWidthWarningsInYaml(yaml, 1);
    if (yamlDictumWidths.length > 0) {
      warnings.push({ file: entry, message: dictumWidthWarningsMessage(yamlDictumWidths) });
    }
  }
  if (!yaml) {
    handleNoFrontmatter(entry, body, raw, errors, warnings);
    return false;
  }
  return await validateParsedYaml(cwd, entry, yaml, body, slugs, errors, warnings);
}

async function validateFrontmatter(cwd: string): Promise<ValidationResult> {
  const entries = await listMarkdownDocuments(cwd);
  const errors: ValidationError[] = [];
  const warnings: ValidationError[] = [];
  const slugs = new Map<string, string>();
  for (const entry of entries) {
    await validateSingleEntry(cwd, entry, slugs, errors, warnings);
  }
  return { errors, warnings, count: entries.length };
}

interface ValidationSummary {
  ok: boolean;
  documents: number;
  errors: ValidationError[];
  warnings: ValidationError[];
}

async function collectConfigIssues(
  cwd: string,
  config: Awaited<ReturnType<typeof loadSiteConfig>>,
): Promise<{ errors: ValidationError[]; warnings: ValidationError[] }> {
  const errors: ValidationError[] = [];
  const warnings: ValidationError[] = [];
  validateDisabledFilters(config.disabledFilters, join(cwd, 'iteraciones.config.yaml'), projectFilterNames(config.luaFilters));
  const effectiveDisabledPreamble = resolveEffectiveDisabledPreamble(resolveDisabledPreambleConfig(config));
  validateDisabledPreambleFilters(effectiveDisabledPreamble);
  for (const issue of validatePreambleDependencies(effectiveDisabledPreamble)) {
    if (issue.severity === 'error') {
      errors.push({ file: 'iteraciones.config.yaml', message: issue.message });
    } else {
      warnings.push({ file: 'iteraciones.config.yaml', message: issue.message });
    }
  }
  return { errors, warnings };
}

async function collectValidation(cwd: string): Promise<{ summary: ValidationSummary; disabledFiltersCount: number; luaFiltersCount: number }> {
  const configErrors: ValidationError[] = [];
  const configWarnings: ValidationError[] = [];
  let disabledFiltersCount = 0;
  let luaFiltersCount = 0;
  try {
    const config = await loadSiteConfig(cwd);
    disabledFiltersCount = config.disabledFilters?.length ?? 0;
    luaFiltersCount = config.luaFilters?.length ?? 0;
    const { errors, warnings } = await collectConfigIssues(cwd, config);
    configErrors.push(...errors);
    configWarnings.push(...warnings);
    for (const issue of [...validateConfigRules(config), ...(await validateConfigFilePaths(cwd, config))]) {
      if (issue.severity === 'error') {
        configErrors.push({ file: 'iteraciones.config.yaml', message: issue.message });
      } else {
        configWarnings.push({ file: 'iteraciones.config.yaml', message: issue.message });
      }
    }
  } catch (err) {
    if (err instanceof ConfigError) {
      configErrors.push({ file: relative(cwd, err.configPath), message: err.message });
    } else {
      configErrors.push({ file: 'iteraciones.config.yaml', message: err instanceof Error ? err.message : String(err) });
    }
  }
  const { errors: fmErrors, warnings, count: docCount } = await validateFrontmatter(cwd);
  return {
    summary: {
      ok: [...configErrors, ...fmErrors].length === 0,
      documents: docCount,
      errors: [...configErrors, ...fmErrors],
      warnings: [...configWarnings, ...warnings],
    },
    disabledFiltersCount,
    luaFiltersCount,
  };
}

export async function validateProject(cwd: string, options: { json?: boolean } = {}): Promise<void> {
  const { summary, disabledFiltersCount, luaFiltersCount } = await collectValidation(cwd);
  if (options.json) {
    writeJson(summary);
    if (!summary.ok) process.exitCode = 1;
    return;
  }
  const { errors, warnings: allWarnings, documents: docCount, ok } = summary;

  if (allWarnings.length > 0) {
    logWarning(`${plural(allWarnings.length, 'advertencia')}:`, 'validate');
    for (const w of allWarnings) {
      logWarning(`${w.file}: ${w.message}`, 'validate');
    }
  }

  if (ok) {
    const detail: string[] = [plural(docCount, 'documento')];
    if (disabledFiltersCount > 0) detail.push(`${plural(disabledFiltersCount, 'filter', 'filters')} desactivados`);
    if (luaFiltersCount > 0) detail.push(`${plural(luaFiltersCount, 'lua-filter', 'lua-filters')}`);
    logInfo(`sin errores — ${detail.join(', ')}.`, 'validate');
    if (docCount === 0) {
      logInfo("si estás empezando, ejecuta 'iteraciones init sveltia' para crear el admin y un texto inicial", 'validate');
    }
    return;
  }

  logError(`${plural(errors.length, 'error')}:`, 'validate');
  for (const e of errors) {
    logError(`${e.file}: ${e.message}`, 'validate');
  }
  process.exitCode = 1;
}
